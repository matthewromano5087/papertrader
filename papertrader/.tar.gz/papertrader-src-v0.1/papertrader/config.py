from pathlib import Path


DATABASE_URL = "sqlite:///./test.db"
SECRET = "SECRET"
STATIC_DIR = Path(__file__).parent / 'static'
